﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace DataConnectionString
{
    public partial class Form1 : Form
    {
        private OleDbConnection connection = new OleDbConnection();
        public Form1()
        {
            
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=K:\1Westchester Community College\GUI DEVELOPMENT\Programs\DataConnectionStringStart\DataConnectionString\Contactmanager.accdb;
Persist Security Info=False;";

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "select * from contacts;";
                //command.CommandText = "select * from contacts where [Last Name] = '" + txt_lastname.Text + "' AND [First Name] = '" + txt_FirstName.Text + "';";
                OleDbDataReader reader = command.ExecuteReader();

                int count = 0;
                while (reader.Read())
                {

                    cmb_Names.Items.Add(reader[2].ToString() + ", " + reader[3].ToString());

                    count = count + 1;
                }
                if (count == 1)
                {
                    MessageBox.Show("record found");
                }
                else
                {
                    MessageBox.Show("miss");
                }


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {


        }

    }
}
